// Realpage/input/input.js
var plugin = requirePlugin("chatbot")
const db = wx.cloud.database()
const changs = db.collection('chang')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    inputValue: '',
    databack: '',
    usersign: '',
    userInfo: {},
    hasUserInfo: false,
    canIUseGetUserProfile: false,
    emotion: '无',
    answer: '相信自己',
    randomNumtemp:0
  },

  bindKeyInput: function (e) {
    this.setData({
      inputValue: e.detail.value
    })
    console.log(this.data)
  },

  //   bindKeyLoad: function (e) {

  //     var myDate = new Date();
  //     var mytime=myDate.toLocaleString( ); 
  //     console.log(mytime)
  //     var that=this
  //     db.collection('chang').add({

  //         // data 字段表示需新增的 JSON 数据
  //         data: {

  //           inputs:that.data.inputValue,
  //           userName:that.data.userInfo.nickName,
  //           QuestionAnswer:"测试",
  //           description: "learn cloud database",
  //           due: mytime,
  //           userdecide:that.data.usersign,
  //         },
  //         success: function(res) {
  //           // res 是一个对象，其中有 _id 字段标记刚创建的记录的 id
  //           console.log(res)
  //         }
  //       })
  //   },


  search: function () {
    this.randomNum()
    this.getAnswer()
    // const txt = this.data.inputValue;
    // plugin.api.nlp('sentiment', { q: txt, mode: '6class' }).then(res => {
    //  // console.log("sentiment result : ", res)
    //   this.setData({
    //     emotion: res.result[0][0]
    //   })
    // })
    var that=this
    db.collection('ans').where({
      emotion: this.data.emotion
    })
      .get({
        success: function (res) {
          // res.data 是包含以上定义的两条记录的数组
          console.log("res", res)
          console.log("daan1", res.data)
          that.setData({
            answer: res.data[that.data.randomNumtemp].answer
          })
          //  console.log("145")
          // console.log("daa",res.data[0].answer)
          //console.log("123")
          console.log("9999", that.data.answer)
        }

      })
      setTimeout(() => {
       console.log("123456789", this.data.answer)
      var that = this
      console.log("that.data.answer is",that.data.answer)

      var myDate = new Date();
      var mytime = myDate.toLocaleString();
      console.log(mytime)
     
      
      db.collection('chang').add({
  
        // data 字段表示需新增的 JSON 数据
        data: {
  
          inputs: that.data.inputValue,
          userName: that.data.userInfo.nickName,
          QuestionAnswer: that.data.answer,
          description: "learn cloud database",
          due: mytime,
          emotion: this.data.emotion,
          userdecide: that.data.usersign,
        },
        success: function (res) {
          // res 是一个对象，其中有 _id 字段标记刚创建的记录的 id
          console.log(res)
        }
      })
  
  
  
  


    }, 1000)
    
    
    // var myDate = new Date();
    // var mytime = myDate.toLocaleString();
    // console.log(mytime)
   
    
    // db.collection('chang').add({

    //   // data 字段表示需新增的 JSON 数据
    //   data: {

    //     inputs: that.data.inputValue,
    //     userName: that.data.userInfo.nickName,
    //     QuestionAnswer: that.data.answer,
    //     description: "learn cloud database",
    //     due: mytime,
    //     emotion: this.data.emotion,
    //     userdecide: that.data.usersign,
    //   },
    //   success: function (res) {
    //     // res 是一个对象，其中有 _id 字段标记刚创建的记录的 id
    //     console.log(res)
    //   }
    // })



    console.log("ceshi123456daan", this.data.emotion)

    db.collection('ans').where({
      emotion: this.data.emotion
    })
      .get({
        success: function (res) {
          // res.data 是包含以上定义的两条记录的数组
          console.log("daan1", res.data)
        }
      })

      this.show();

  },


  getAnswer: function () {
    const txt = this.data.inputValue;
    plugin.api.nlp('sentiment', { q: txt, mode: '6class' }).then(res => {
     // console.log("sentiment result : ", res)
      this.setData({
        emotion: res.result[0][0]
      })
    })
  },

 randomNum:function(){
  var randomn =Math.floor(Math.random() * 100)
    this.data.randomNumtemp=randomn%5,
    console.log( this.data.randomNumtemp)
},


  getUserProfile(e) {
    // 推荐使用 wx.getUserProfile 获取用户信息，开发者每次通过该接口获取用户个人信息均需用户确认
    // 开发者妥善保管用户快速填写的头像昵称，避免重复弹窗
    wx.getUserProfile({
      desc: '用于完善会员资料', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
      success: (res) => {
        this.setData({
          userInfo: res.userInfo,
          usersign: res.signature,
          hasUserInfo: true
        })
        console.log(res)
      }
    })

  },


    masterAdd(){

      db.collection('ans').where({
        _id:"0"
      })
        .get({
          success: function (res) {
            // res.data 是包含以上定义的两条记录的数组
            console.log("拿到总数", res)

 db.collection('ans').doc("nums").update({
          // data 传入需要局部更新的数据
          data: {
            // 表示将 done 字段置为 true
           'num.$[]':100,
          },
          success: function(res) {
            console.log(this.data.num)
            console.log("num+1成功",res)
          }
        })


            db.collection('ans').add({
  
             
              data: {
                  _id:res.data[0].num,
                  emotion:"zanding",
                  answer:"zanding"
              },
              success: function (res) {

               
                console.log(res)
              }
            })

             

          }
        })

       


    },


      show:function(){
        // wx.showToast({
        //   title: this.data.answer,
        //   icon:'none'
        // })

        wx.showModal({
          content:this.data.answer,
          title:'答案：'
        })


      },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    // const db=wx.cloud.database();
    // wx.showLoading({
    //   title: '',
    // })
    // db.collection('answer').where({}).get().then(({data})=>{
    //   data.forEach((item)=>{
    //     db.collection("answer").doc(item._id).remove()
    //   })
    // }).catch(res=>{
    //   console.error(res)
    //   wx.hideLoading({})
    //   wx.showToast({
    //     title: '请创建集合。',
    //     icon:"error",
    //   })
    // })
    // var a= db.collection('answer').add({
    //   data:{"posbleanswer":"dagihcevbuyeve"},
    // });
    // //集合初始化
    // Promise.all([a]).then(res=>{
    //   console.log('初始化完成')
    //   wx.showToast({
    //     title: '初始化完成！'
    //   })
    //   wx.hideLoading({
    //   })
    // }).catch(res=>{
    //   console.error(res)
    //   wx.hideLoading({})
    //   wx.showToast({
    //     title: '请创建集合。',
    //     icon:"error",
    //   })
    // })
    if (wx.getUserProfile) {
      this.setData({
        canIUseGetUserProfile: true
      })
    }
  },


  Navito_history(){
    wx.navigateTo({
      url: '/Realpage/history/history',
    })
},
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})