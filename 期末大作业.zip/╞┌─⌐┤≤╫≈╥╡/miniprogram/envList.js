const envList = [{"envId":"cloud1-6gt4vl650ef168d1","alias":"cloud1"},{"envId":"diyi-7gta0xgp261f9275","alias":"diyi"}]
const isMac = false
module.exports = {
    envList,
    isMac
}